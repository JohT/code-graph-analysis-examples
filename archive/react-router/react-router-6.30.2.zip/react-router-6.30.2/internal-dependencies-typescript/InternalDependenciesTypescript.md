# Internal Dependencies
<br>  

### References
- [Analyze java package metrics in a graph database](https://joht.github.io/johtizen/data/2023/04/21/java-package-metrics-analysis.html)
- [Calculate metrics](https://101.jqassistant.org/calculate-metrics/index.html)
- [Neo4j Python Driver](https://neo4j.com/docs/api/python-driver/current)





## 1 - Modules

List the modules this notebook is based on. Different sorting variations help finding modules by their features and support larger code bases where the list of all modules gets very long.

Only the top 30 entries are shown. The whole table can be found in the following CSV report:  
`List_all_Typescript_modules`

    Received notification from DBMS server: {severity: WARNING} {code: Neo.ClientNotification.Statement.UnknownPropertyKeyWarning} {category: UNRECOGNIZED} {title: The provided property key is not in the database} {description: One of the property names in your query is not available in the database, make sure you didn't misspell it or that the label is available when you run this statement in your application (the missing property name is: numberOfGitCommits)} {position: line: 9, column: 31, offset: 594} for query: '// List all existing internal Typescript modules. Requires "Set_localRootPath_for_modules.cypher", "Set_number_of...commits.cypher".\n \n MATCH (internalModule:TS:Module)-[:EXPORTS]->(internalElement:TS)\n  WITH internalModule.name                            AS moduleName\n      ,internalModule.rootProjectName                 AS rootProjectName\n      ,internalModule.localModuleDir                  AS localModuleDir\n      ,internalModule.incomingDependencies            AS incomingDependencies\n      ,internalModule.outgoingDependencies            AS outgoingDependencies\n      ,coalesce(internalModule.numberOfGitCommits, 0) AS numberOfGitCommits\n      ,COUNT(DISTINCT internalElement.globalFqn)      AS numberOfElements\n RETURN rootProjectName, moduleName, numberOfElements, numberOfGitCommits, incomingDependencies, outgoingDependencies'


### Table 1a - Top 30 modules with the highest element count




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>rootProjectName</th>
      <th>moduleName</th>
      <th>numberOfElements</th>
      <th>numberOfGitCommits</th>
      <th>incomingDependencies</th>
      <th>outgoingDependencies</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>react-router-6.30.2</td>
      <td>react-router-dom</td>
      <td>35</td>
      <td>0</td>
      <td>0</td>
      <td>157</td>
    </tr>
    <tr>
      <th>1</th>
      <td>react-router-6.30.2</td>
      <td>react-router-native</td>
      <td>12</td>
      <td>0</td>
      <td>0</td>
      <td>24</td>
    </tr>
    <tr>
      <th>2</th>
      <td>react-router-6.30.2</td>
      <td>react-router</td>
      <td>7</td>
      <td>0</td>
      <td>22</td>
      <td>17</td>
    </tr>
    <tr>
      <th>3</th>
      <td>react-router-6.30.2</td>
      <td>server</td>
      <td>6</td>
      <td>0</td>
      <td>0</td>
      <td>39</td>
    </tr>
  </tbody>
</table>
</div>



### Table 1b - Top 30 modules with the highest number of incoming dependencies

The following table lists the top 30 internal modules that are used the most by other modules (highest count of incoming dependencies, highest in-degree).




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>rootProjectName</th>
      <th>moduleName</th>
      <th>numberOfElements</th>
      <th>numberOfGitCommits</th>
      <th>incomingDependencies</th>
      <th>outgoingDependencies</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>react-router-6.30.2</td>
      <td>react-router</td>
      <td>7</td>
      <td>0</td>
      <td>22</td>
      <td>17</td>
    </tr>
    <tr>
      <th>1</th>
      <td>react-router-6.30.2</td>
      <td>react-router-dom</td>
      <td>35</td>
      <td>0</td>
      <td>0</td>
      <td>157</td>
    </tr>
    <tr>
      <th>2</th>
      <td>react-router-6.30.2</td>
      <td>react-router-native</td>
      <td>12</td>
      <td>0</td>
      <td>0</td>
      <td>24</td>
    </tr>
    <tr>
      <th>3</th>
      <td>react-router-6.30.2</td>
      <td>server</td>
      <td>6</td>
      <td>0</td>
      <td>0</td>
      <td>39</td>
    </tr>
  </tbody>
</table>
</div>



### Table 1c - Top 30 modules with the highest number of outgoing dependencies

The following table lists the top 30 internal modules that are depending on the highest number of other modules (highest count of outgoing dependencies, highest out-degree).




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>rootProjectName</th>
      <th>moduleName</th>
      <th>numberOfElements</th>
      <th>numberOfGitCommits</th>
      <th>incomingDependencies</th>
      <th>outgoingDependencies</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>react-router-6.30.2</td>
      <td>react-router-dom</td>
      <td>35</td>
      <td>0</td>
      <td>0</td>
      <td>157</td>
    </tr>
    <tr>
      <th>1</th>
      <td>react-router-6.30.2</td>
      <td>server</td>
      <td>6</td>
      <td>0</td>
      <td>0</td>
      <td>39</td>
    </tr>
    <tr>
      <th>2</th>
      <td>react-router-6.30.2</td>
      <td>react-router-native</td>
      <td>12</td>
      <td>0</td>
      <td>0</td>
      <td>24</td>
    </tr>
    <tr>
      <th>3</th>
      <td>react-router-6.30.2</td>
      <td>react-router</td>
      <td>7</td>
      <td>0</td>
      <td>22</td>
      <td>17</td>
    </tr>
  </tbody>
</table>
</div>



### Table 1d - Top 30 modules with the lowest element count




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>rootProjectName</th>
      <th>moduleName</th>
      <th>numberOfElements</th>
      <th>numberOfGitCommits</th>
      <th>incomingDependencies</th>
      <th>outgoingDependencies</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>react-router-6.30.2</td>
      <td>server</td>
      <td>6</td>
      <td>0</td>
      <td>0</td>
      <td>39</td>
    </tr>
    <tr>
      <th>1</th>
      <td>react-router-6.30.2</td>
      <td>react-router</td>
      <td>7</td>
      <td>0</td>
      <td>22</td>
      <td>17</td>
    </tr>
    <tr>
      <th>2</th>
      <td>react-router-6.30.2</td>
      <td>react-router-native</td>
      <td>12</td>
      <td>0</td>
      <td>0</td>
      <td>24</td>
    </tr>
    <tr>
      <th>3</th>
      <td>react-router-6.30.2</td>
      <td>react-router-dom</td>
      <td>35</td>
      <td>0</td>
      <td>0</td>
      <td>157</td>
    </tr>
  </tbody>
</table>
</div>



### Table 1e - Top 30 modules with the lowest number of incoming dependencies

The following table lists the top 30 internal modules that are used the least by other modules (lowest count of incoming dependencies, lowest in-degree).




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>rootProjectName</th>
      <th>moduleName</th>
      <th>numberOfElements</th>
      <th>numberOfGitCommits</th>
      <th>incomingDependencies</th>
      <th>outgoingDependencies</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>react-router-6.30.2</td>
      <td>react-router-dom</td>
      <td>35</td>
      <td>0</td>
      <td>0</td>
      <td>157</td>
    </tr>
    <tr>
      <th>1</th>
      <td>react-router-6.30.2</td>
      <td>react-router-native</td>
      <td>12</td>
      <td>0</td>
      <td>0</td>
      <td>24</td>
    </tr>
    <tr>
      <th>2</th>
      <td>react-router-6.30.2</td>
      <td>server</td>
      <td>6</td>
      <td>0</td>
      <td>0</td>
      <td>39</td>
    </tr>
    <tr>
      <th>3</th>
      <td>react-router-6.30.2</td>
      <td>react-router</td>
      <td>7</td>
      <td>0</td>
      <td>22</td>
      <td>17</td>
    </tr>
  </tbody>
</table>
</div>



### Table 1f - Top 30 modules with the lowest number of outgoing dependencies

The following table lists the top 30 internal modules that are depending on the lowest number of other modules (lowest count of outgoing dependencies, lowest out-degree).




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>rootProjectName</th>
      <th>moduleName</th>
      <th>numberOfElements</th>
      <th>numberOfGitCommits</th>
      <th>incomingDependencies</th>
      <th>outgoingDependencies</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>react-router-6.30.2</td>
      <td>react-router</td>
      <td>7</td>
      <td>0</td>
      <td>22</td>
      <td>17</td>
    </tr>
    <tr>
      <th>1</th>
      <td>react-router-6.30.2</td>
      <td>react-router-native</td>
      <td>12</td>
      <td>0</td>
      <td>0</td>
      <td>24</td>
    </tr>
    <tr>
      <th>2</th>
      <td>react-router-6.30.2</td>
      <td>server</td>
      <td>6</td>
      <td>0</td>
      <td>0</td>
      <td>39</td>
    </tr>
    <tr>
      <th>3</th>
      <td>react-router-6.30.2</td>
      <td>react-router-dom</td>
      <td>35</td>
      <td>0</td>
      <td>0</td>
      <td>157</td>
    </tr>
  </tbody>
</table>
</div>



## 2 - Cyclic Dependencies

Cyclic dependencies occur when one module uses an elements of another module and vice versa. 
These dependencies can lead to problems when one of these modules needs to be changed.

### Table 2a - Cyclic Dependencies Overview

Show the top 40 cyclic dependencies sorted by the most promising to resolve first. This is done by calculating the number of forward dependencies (first cycle participant to second cycle participant) in relation to backward dependencies (second cycle participant back to first cycle participant). The higher this rate (approaching 1), the easier it should be to resolve the cycle by focussing on the few backward dependencies.

Only the top 40 entries are shown. The whole table can be found in the following CSV report:  
`Cyclic_Dependencies_for_Typescript`

**Columns:**
- *projectFileName* identifies the project of the first participant of the cycle
- *modulePathName* identifies the module of the first participant of the cycle
- *dependentProjectFileName* identifies the project of the second participant of the cycle
- *dependentModulePathName* identifies the module of the second participant of the cycle
- *forwardToBackwardBalance* is between 0 and 1. High for many forward and few backward dependencies.
- *numberForward* contains the number of dependencies from the first participant of the cycle to the second one
- *numberBackward* contains the number of dependencies from the second participant of the cycle back to the first one
- *someForwardDependencies* lists some forward dependencies in the text format "type1 -> type2"
- *backwardDependencies* lists the backward dependencies in the format "type1 <- type2" that are recommended to get resolved




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>projectFileName</th>
      <th>moduleName</th>
      <th>dependentProjectFileName</th>
      <th>dependentModulePathName</th>
      <th>forwardToBackwardBalance</th>
      <th>numberForward</th>
      <th>numberBackward</th>
      <th>forwardDependencyExamples</th>
      <th>backwardDependencyExamples</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>
</div>



### Table 2b - Cyclic Dependencies Break Down

Lists modules with cyclic dependencies with every dependency in a separate row sorted by the most promising dependency first.

Only the top 40 entries are shown. The whole table can be found in the following CSV report:  
`Cyclic_Dependencies_Breakdown_for_Typescript`

**Columns in addition to Table 2a:**
- *dependency* shows the cycle dependency in the text format "type1 -> type2" (forward) or "type2<-type1" (backward)




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>projectFileName</th>
      <th>moduleName</th>
      <th>dependentProjectFileName</th>
      <th>dependentModulePathName</th>
      <th>dependency</th>
      <th>forwardToBackwardBalance</th>
      <th>numberForward</th>
      <th>numberBackward</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>
</div>



### Table 2c - Cyclic Dependencies Break Down - Backward Dependencies Only

Lists modules with cyclic dependencies with every dependency in a separate row sorted by the most promising  dependency first. This table only contains the backward dependencies from the second participant of the cycle back to the first one that are the most promising to resolve.

Only the top 40 entries are shown. The whole table can be found in the following CSV report:  
`Cyclic_Dependencies_Breakdown_BackwardOnly_for_Typescript`




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>projectFileName</th>
      <th>moduleName</th>
      <th>dependentProjectFileName</th>
      <th>dependentModulePathName</th>
      <th>dependency</th>
      <th>forwardToBackwardBalance</th>
      <th>numberForward</th>
      <th>numberBackward</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>
</div>



## 3 - Module Usage

### Table 3a - Elements that are used by multiple modules

This table shows the top 40 modules that are used by the highest number of different modules. The whole table can be found in the CSV report `WidelyUsedTypescriptElements`.


    Received notification from DBMS server: {severity: WARNING} {code: Neo.ClientNotification.Statement.UnknownLabelWarning} {category: UNRECOGNIZED} {title: The provided label is not in the database.} {description: One of the labels in your query is not available in the database, make sure you didn't misspell it or that the label is available when you run this statement in your application (the missing label name is: TestRelated)} {position: line: 3, column: 33, offset: 91} for query: "// List elements that are used by many different modules\n \n MATCH (sourceModule:TS&Module&!TestRelated)-[:EXPORTS]->(sourceElement:TS)\n MATCH (sourceElement)-[:DEPENDS_ON]->(dependentElement:TS&!Module&!ExternalModule)\n MATCH (dependentModule:TS&Module&!TestRelated)-[:EXPORTS]->(dependentElement)\n WHERE sourceModule <> dependentModule\n  WITH dependentElement\n      ,labels(dependentElement)               AS dependentElementLabels\n      ,COUNT(DISTINCT sourceModule.globalFqn) AS numberOfUsingModules\n UNWIND dependentElementLabels AS dependentElementLabel\n   WITH *\n  WHERE NOT dependentElementLabel = 'TS' // Filter out generic TS label\n RETURN dependentElement.globalFqn            AS fullQualifiedDependentElementName\n       ,dependentElement.moduleName           AS dependentElementModuleName\n       ,dependentElement.name                 AS dependentElementName\n       ,dependentElementLabel                 AS dependentElementLabels\n       ,numberOfUsingModules\n  ORDER BY numberOfUsingModules DESC, dependentElementName ASC\nLIMIT 40"


    Received notification from DBMS server: {severity: WARNING} {code: Neo.ClientNotification.Statement.UnknownLabelWarning} {category: UNRECOGNIZED} {title: The provided label is not in the database.} {description: One of the labels in your query is not available in the database, make sure you didn't misspell it or that the label is available when you run this statement in your application (the missing label name is: TestRelated)} {position: line: 5, column: 36, offset: 254} for query: "// List elements that are used by many different modules\n \n MATCH (sourceModule:TS&Module&!TestRelated)-[:EXPORTS]->(sourceElement:TS)\n MATCH (sourceElement)-[:DEPENDS_ON]->(dependentElement:TS&!Module&!ExternalModule)\n MATCH (dependentModule:TS&Module&!TestRelated)-[:EXPORTS]->(dependentElement)\n WHERE sourceModule <> dependentModule\n  WITH dependentElement\n      ,labels(dependentElement)               AS dependentElementLabels\n      ,COUNT(DISTINCT sourceModule.globalFqn) AS numberOfUsingModules\n UNWIND dependentElementLabels AS dependentElementLabel\n   WITH *\n  WHERE NOT dependentElementLabel = 'TS' // Filter out generic TS label\n RETURN dependentElement.globalFqn            AS fullQualifiedDependentElementName\n       ,dependentElement.moduleName           AS dependentElementModuleName\n       ,dependentElement.name                 AS dependentElementName\n       ,dependentElementLabel                 AS dependentElementLabels\n       ,numberOfUsingModules\n  ORDER BY numberOfUsingModules DESC, dependentElementName ASC\nLIMIT 40"





<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fullQualifiedDependentElementName</th>
      <th>dependentElementModuleName</th>
      <th>dependentElementName</th>
      <th>dependentElementLabels</th>
      <th>numberOfUsingModules</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>
</div>



### Table 3b - Elements that are used by multiple modules

This table shows the top 30 modules that only use a few (compared to all existing) elements of another module.
The whole table can be found in the CSV report `ModuleElementsUsageTypescript`.

    Received notification from DBMS server: {severity: WARNING} {code: Neo.ClientNotification.Statement.UnknownLabelWarning} {category: UNRECOGNIZED} {title: The provided label is not in the database.} {description: One of the labels in your query is not available in the database, make sure you didn't misspell it or that the label is available when you run this statement in your application (the missing label name is: TestRelated)} {position: line: 3, column: 33, offset: 122} for query: '// How many elements compared to all existing are used by dependent Typescript modules?\n \n MATCH (sourceModule:TS&Module&!TestRelated)-[:EXPORTS]-(sourceElement:TS)\n MATCH (sourceElement)-[:DEPENDS_ON]->(dependentElement:TS&!Module&!ExternalModule)\n MATCH (dependentModule:TS&Module&!TestRelated)-[:EXPORTS]->(dependentElement)\n WHERE sourceModule <> dependentModule\n MATCH (dependentModule)-[:EXPORTS]->(dependentModuleElement:TS)\n   WITH sourceModule.name                                  AS sourceModuleName\n       ,dependentModule.name                               AS dependentModuleName\n       ,COUNT(DISTINCT dependentElement.globalFqn)         AS dependentElementsCount\n       ,COUNT(DISTINCT dependentModuleElement.globalFqn)   AS dependentModuleElementsCount\n       ,collect(DISTINCT dependentElement.globalFqn)[0..4] AS dependentElementFullNameExamples\n       ,collect(DISTINCT dependentElement.name)[0..4]      AS dependentElementNameExamples\n RETURN sourceModuleName\n       ,dependentModuleName\n       ,dependentElementsCount\n       ,dependentModuleElementsCount\n       ,toFloat(dependentElementsCount) / (dependentModuleElementsCount + 1E-38) AS elementUsagePercentage\n       ,dependentElementFullNameExamples\n       ,dependentElementNameExamples\n ORDER BY elementUsagePercentage ASC\nLIMIT 30'


    Received notification from DBMS server: {severity: WARNING} {code: Neo.ClientNotification.Statement.UnknownLabelWarning} {category: UNRECOGNIZED} {title: The provided label is not in the database.} {description: One of the labels in your query is not available in the database, make sure you didn't misspell it or that the label is available when you run this statement in your application (the missing label name is: TestRelated)} {position: line: 5, column: 36, offset: 284} for query: '// How many elements compared to all existing are used by dependent Typescript modules?\n \n MATCH (sourceModule:TS&Module&!TestRelated)-[:EXPORTS]-(sourceElement:TS)\n MATCH (sourceElement)-[:DEPENDS_ON]->(dependentElement:TS&!Module&!ExternalModule)\n MATCH (dependentModule:TS&Module&!TestRelated)-[:EXPORTS]->(dependentElement)\n WHERE sourceModule <> dependentModule\n MATCH (dependentModule)-[:EXPORTS]->(dependentModuleElement:TS)\n   WITH sourceModule.name                                  AS sourceModuleName\n       ,dependentModule.name                               AS dependentModuleName\n       ,COUNT(DISTINCT dependentElement.globalFqn)         AS dependentElementsCount\n       ,COUNT(DISTINCT dependentModuleElement.globalFqn)   AS dependentModuleElementsCount\n       ,collect(DISTINCT dependentElement.globalFqn)[0..4] AS dependentElementFullNameExamples\n       ,collect(DISTINCT dependentElement.name)[0..4]      AS dependentElementNameExamples\n RETURN sourceModuleName\n       ,dependentModuleName\n       ,dependentElementsCount\n       ,dependentModuleElementsCount\n       ,toFloat(dependentElementsCount) / (dependentModuleElementsCount + 1E-38) AS elementUsagePercentage\n       ,dependentElementFullNameExamples\n       ,dependentElementNameExamples\n ORDER BY elementUsagePercentage ASC\nLIMIT 30'





<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sourceModuleName</th>
      <th>dependentModuleName</th>
      <th>dependentElementsCount</th>
      <th>dependentModuleElementsCount</th>
      <th>elementUsagePercentage</th>
      <th>dependentElementFullNameExamples</th>
      <th>dependentElementNameExamples</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>
</div>



### Table 3c - Distance distribution between dependent files

This table shows the file directory distance distribution between dependent files. Intuitively, the distance is given by the fewest number of change directory commands needed to navigate between a file and a dependency it uses. Those are aggregate to see how many dependent files are in the same directory, how many are just one change directory command apart, and so on.




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>dependency.fileDistanceAsFewestChangeDirectoryCommands</th>
      <th>numberOfDependencies</th>
      <th>numberOfDependencyUsers</th>
      <th>numberOfDependencyProviders</th>
      <th>examples</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>4</td>
      <td>3</td>
      <td>3</td>
      <td>1</td>
      <td>[./server.tsx uses ./index.ts, ./index.tsx uses ./index.ts, ./index.tsx uses ./index.ts]</td>
    </tr>
  </tbody>
</table>
</div>


